<?php
/**
 * View for font awesome icon
 *
 * @package    Cherry_Framework
 * @subpackage View
 * @author     Cherry Team <support@cherryframework.com>
 * @copyright  Copyright (c) 2012 - 2015, Cherry Team
 * @link       http://www.cherryframework.com/
 * @license    http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 */
?>
<i class="fa <?php echo $__data['class']; ?>"></i>
