/**
 * TM Header Banner scripts
 */
/*globals CherryJsCore, Cookies*/
! ( function( $ ) {
	'use strict';

	CherryJsCore.utilites.namespace( 'tm_header_banner' );

	CherryJsCore.tm_header_banner = {

		init: function() {

			if ( CherryJsCore.status.is_ready ) {
				this.ready.call( this );
			} else {
				CherryJsCore.variable.$document.on( 'ready', this.ready.bind( this ) );
			}
		},

		debounce: function( callback, threshold ) {
			var timeout;

			return function debounced() {
				function delayed() {
					callback();
					timeout = null;
				}

				if ( timeout ) {
					clearTimeout( timeout );
				}

				timeout = setTimeout( delayed, threshold );
			};
		},

		ready: function() {
			var _this = this,
				init,
				$adminbar = $( '#wpadminbar' ),
				$headerBanner = $( '.tm-hb__wrapper' ),
				$body = $( 'body' ),
				$preloader = $( '.page-preloader-cover' ),
				originalAnimationSpeed = $headerBanner.data( 'animation-speed' ) || 200,
				clearCookie = 'true' === $headerBanner.data( 'cc' ),
				scrollOffset,
				adminBarOffset,
				animationSpeed,
				headerBannerHeight,
				cookieOptions = {
					path: ''
				},
				recalc;

			if ( 0 === $headerBanner.length ) {
				return false;
			}

			animationSpeed = originalAnimationSpeed;

			recalc = function() {

				headerBannerHeight = $headerBanner.height();
				adminBarOffset = $adminbar.height();

				$headerBanner.css( {
					height: 0,
					display: 'block'
				} ).animate( {
					height: headerBannerHeight,
					opacity: 1,
					top: adminBarOffset
				}, animationSpeed );

				$body.animate( {
					paddingTop: headerBannerHeight
				}, animationSpeed );
			};

			init = function() {
				if ( $headerBanner.hasClass( 'tm-hb__wrapper--animate' ) ) {

					recalc();
					$headerBanner.addClass( 'tm-hb__wrapper--animated' );

					window.addEventListener( 'scroll', _this.debounce( function() {
						scrollOffset = window.scrollY;
						adminBarOffset = $adminbar.height();

						if ( $adminbar.hasClass( 'mobile' ) ) {
							if ( adminBarOffset < scrollOffset &&
								 $headerBanner.hasClass( 'tm-hb__wrapper--floating' ) &&
								( window.hasOwnProperty( 'orientation' ) &&
								  90 !== Math.abs( window.orientation ) ) ) {
								$headerBanner.css( {
									top: 0
								}, 200 );
							} else {
								$headerBanner.css( {
									top: adminBarOffset
								}, 200 );
							}
						}
					}, 10 ) );
				}

				if ( Cookies ) {
					if ( clearCookie ) {
						Cookies.remove( 'tm-header-banner-clicked', cookieOptions );
					}
				}
			};

			if ( 0 < $preloader.length ) {
				setTimeout( init, 1000 );
			} else {
				init();

				window.addEventListener( 'orientationchange', recalc );
			}

			$headerBanner.on( 'click', 'a, button', function() {
				$headerBanner.removeClass( 'tm-hb__wrapper--animated' );

				if ( $headerBanner.data( 'reactivation' ) ) {
					cookieOptions.expires = $headerBanner.data( 'reactivation' );
				}

				if ( Cookies ) {
					Cookies.set( 'tm-header-banner-clicked', 'yes', cookieOptions );
				}

				animationSpeed = originalAnimationSpeed;

				if ( ! $headerBanner.hasClass( 'tm-hb__wrapper--animate' ) ) {
					$headerBanner.css( {
						display: 'none'
					} );
					$body.removeClass( 'tm-hb-enabled' );

					return false;
				}

				$headerBanner.animate( {
					height: 0,
					opacity: 0
				}, animationSpeed );

				$body.animate( {
					paddingTop: 0
				}, animationSpeed, function() {
					$body.removeClass( 'tm-hb-enabled' );
				} );
			} );
		}
	};

	CherryJsCore.tm_header_banner.init();

}( jQuery ) );
