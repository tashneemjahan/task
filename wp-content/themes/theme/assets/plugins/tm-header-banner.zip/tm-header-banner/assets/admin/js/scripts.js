/**
 * TM Header Banner admin scripts
 */
/*globals CherryJsCore, tmHeaderBannerPluginSettings*/
! ( function( $ ) {
	'use strict';

	CherryJsCore.utilites.namespace( 'tm_header_banner_admin' );

	CherryJsCore.tm_header_banner_admin = {
		ajaxRequestSuccess: true,
		init: function() {

			if ( CherryJsCore.status.is_ready ) {
				this.readyRender( this );
			} else {
				CherryJsCore.variable.$document.on( 'ready', this.readyRender( this ) );
			}
		},
		readyRender: function( self ) {

			var $projectsOptionsForm = $( '#tm-header-banner-options-form' ),
				$saveButton = $( '#tm-header-banner-save-options', $projectsOptionsForm ),
				$defineAsDefaultButton = $( '#tm-header-banner-define-as-default', $projectsOptionsForm ),
				$restoreButton = $( '#tm-header-banner-restore-options', $projectsOptionsForm );

				$saveButton.on( 'click', {
					self: self,
					optionsForm: $projectsOptionsForm,
					ajaxRequestType: 'save'
				}, self.ajaxRequest );

				$defineAsDefaultButton.on( 'click', {
					self: self,
					optionsForm: $projectsOptionsForm,
					ajaxRequestType: 'define_as_default'
				}, self.ajaxRequest );

				$restoreButton.on( 'click', {
					self: self,
					optionsForm: $projectsOptionsForm,
					ajaxRequestType: 'restore'
				}, self.ajaxRequest );

		},
		ajaxRequest: function( event ) {

			var self = event.data.self,
				$projectsOptionsForm = event.data.optionsForm,
				$cherrySpinner = $( '.cherry-spinner-wordpress', $projectsOptionsForm ),
				ajaxRequestType = event.data.ajaxRequestType,
				serializedArray = $projectsOptionsForm.serializeObject(),
				data = {
					nonce: CherryJsCore.variable.security,
					action: 'tm_header_banner_ajax_request',
					post_array: serializedArray,
					type: ajaxRequestType
				};

			if ( ! self.ajaxRequestSuccess ) {
				self.ajaxRequest.abort();
				self.noticeCreate( 'error-notice', tmHeaderBannerPluginSettings.please_wait_processing );
			}

			self.ajaxRequest = jQuery.ajax( {
				type: 'POST',
				url: wp.ajax.settings.url,
				data: data,
				cache: false,
				beforeSend: function() {
					self.ajaxRequestSuccess = false;
					$cherrySpinner.fadeIn();
				},
				success: function( response ) {
					self.ajaxRequestSuccess = true;
					$cherrySpinner.fadeOut();
					self.noticeCreate( response.type, response.message );
					if ( 'restore' === ajaxRequestType ) {
						window.location.href = tmHeaderBannerPluginSettings.redirect_url;
					}
				},
				dataType: 'json'
			} );

			return false;
		},
		noticeCreate: function( type, message ) {
			var notice = $( '<div class="notice-box ' + type + '"><span class="dashicons"></span><div class="inner">' + message + '</div></div>' ),
				rightDelta = 0,
				timeoutId;

			$( 'body' ).prepend( notice );
			reposition();
			rightDelta = -1 * ( notice.outerWidth( true ) + 10 );
			notice.css( {
				'right': rightDelta
			} );

			timeoutId = setTimeout( function() {
				notice.css( {
					'right': 10
				} ).addClass( 'show-state' );
			}, 100 );

			timeoutId = setTimeout( function() {
				rightDelta = -1 * ( notice.outerWidth( true ) + 10 );

				notice.css( {
					right: rightDelta
				} ).removeClass( 'show-state' );
			}, 4000 );

			timeoutId = setTimeout( function() {
				notice.remove();
				clearTimeout( timeoutId );
			}, 4500 );

			function reposition() {
				var topDelta = 100;

				$( '.notice-box' ).each( function() {
					$( this ).css( { top: topDelta } );
					topDelta += $( this ).outerHeight( true );
				} );
			}
		}
	};

	CherryJsCore.tm_header_banner_admin.init();

}( jQuery ) );
