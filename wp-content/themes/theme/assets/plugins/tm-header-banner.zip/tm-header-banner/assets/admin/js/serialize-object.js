/**
 * Serialize object
 */
! ( function( $ ) {
	'use strict';

	$.fn.serializeObject = function() {

		var self = this,
			serializedObj = {},
			pushCounters = {},
			patterns = {
				'validate': /^[a-zA-Z][a-zA-Z0-9_-]*(?:\[(?:\d*|[a-zA-Z0-9_-]+)\])*$/,
				'key':      /[a-zA-Z0-9_-]+|(?=\[\])/g,
				'push':     /^$/,
				'fixed':    /^\d+$/,
				'named':    /^[a-zA-Z0-9_-]+$/
			},
			k,
			keys,
			merge,
			reverseKey;

		this.build = function( base, key, value ) {
			base[ key ] = value;

			return base;
		};

		this.push_counter = function( key ) {
			if ( undefined === pushCounters[ key ] ) {
				pushCounters[ key ] = 0;
			}

			return pushCounters[ key ]++;
		};

		$.each( $( this ).serializeArray(), function() {

			// Skip invalid keys
			if ( ! patterns.validate.test( this.name ) ) {
				return;
			}

			keys = this.name.match( patterns.key );
			merge = this.value;
			reverseKey = this.name;

			while ( undefined !== ( k = keys.pop() ) ) {

				// Adjust reverseKey
				reverseKey = reverseKey.replace( new RegExp( '\\[' + k + '\\]$' ), '' );

				// Push
				if ( k.match( patterns.push ) ) {
					merge = self.build( [], self.push_counter( reverseKey ), merge );
				}

				// Fixed
				else if ( k.match( patterns.fixed ) ) {
					merge = self.build( [], k, merge );
				}

				// Named
				else if ( k.match( patterns.named ) ) {
					merge = self.build( {}, k, merge );
				}
			}

			serializedObj = $.extend( true, serializedObj, merge );
		});

		return serializedObj;
	};

}( jQuery ) );
