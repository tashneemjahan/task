<?php
/**
 * The banner itself.
 *
 * @package    TM_Header_Banner
 * @subpackage View
 * @author     Template Monster
 * @license    GPL-3.0+
 * @copyright  2002-2016, Template Monster
 */
?>

<style scoped>
.tm-hb__wrapper {

<?php
	foreach ( $styles as $property => $value ) {

		if ( ! empty( $value ) ) {

			if ( 'background-position' === $property ) {
				$value = str_replace( '-', ' ', $value );
			}

			if ( 'background-image' === $property ) {
				$value = sprintf( 'url("%s")', esc_url( wp_get_attachment_url( $value ) ) );
			} else {
				$value = esc_html( $value );
			}

			echo sprintf( '%1$s: %2$s;', esc_html( $property ), $value );
		}
	}
?>
}
</style>
