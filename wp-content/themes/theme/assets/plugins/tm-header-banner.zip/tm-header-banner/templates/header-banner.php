<?php
/**
 * The banner itself.
 *
 * @package    TM_Header_Banner
 * @subpackage View
 * @author     Template Monster
 * @license    GPL-3.0+
 * @copyright  2002-2016, Template Monster
 */

$wrapper_atts = array(
	'class' => sprintf( 'tm-hb__wrapper tm-hb__wrapper--%s', $data['position_type'] ),
);

if ( $data['animate'] ) {
	$wrapper_atts['class'] .= ' tm-hb__wrapper--animate';
	$wrapper_atts['data-animation-speed'] = $data['animation_speed'];
}

if ( $data['reactivation_always'] || ! $data['clicked'] || $data['refresh'] ) {
	$wrapper_atts['data-cc'] = 'true';
}

if ( $data['reactivation_on'] ) {
	$wrapper_atts['data-reactivation'] = $data['reactivation'];
}

?>
<?php echo sprintf( '<div%s>', TM_Header_Banner::pack_atts( $wrapper_atts ) ) ?>
	<a href="#" class="tm-hb__close" title="<?php echo esc_html__( 'Close', 'tm-header-banner' ); ?>">
		<i class="tm-hb__icon tm-hb__icon-times"></i>
	</a>
	<div class="<?php echo sprintf( 'tm-hb__content tm-hb__content--%s', esc_attr( $data['content_alignment'] ) ); ?>">
		<h3 class="tm-hb__title"><?php echo esc_html( $data['title'] ); ?></h3>
		<?php echo $data['description']; ?>
	</div>
</div>
