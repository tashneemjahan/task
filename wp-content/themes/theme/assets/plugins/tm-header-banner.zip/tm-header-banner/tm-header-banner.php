<?php
/**
 * Plugin Name: TM Header Banner
 * Plugin URI:  http://templatemonster.com/
 * Description: Great WordPress plugin for displaying various messages globally on your website. You can notify your visitors about incoming events, latest news and even add the advertisement to the most top area of your website.
 * Version:     1.0.0
 * Author:      TemplateMonster
 * Author URI:  http://templatemonster.com/
 * Text Domain: tm-header-banner
 * License:     GPL-3.0+
 * License URI: http://www.gnu.org/licenses/gpl-3.0.txt
 * Domain Path: /languages
 *
 * @package TM_Header_Banner
 * @author  TemplateMonster
 * @version 1.0.0
 * @license GPL-3.0+
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die();
}

// If class `Tm_Header_Banner` doesn't exists yet.
if ( ! class_exists( 'Tm_Header_Banner' ) ) {

	/**
	 * Sets up and initializes the Cherry Gallery plugin.
	 */
	class Tm_Header_Banner {

		/**
		 * A reference to an instance of this class.
		 *
		 * @since 1.0.0
		 * @var   object
		 */
		private static $instance = null;

		/**
		 * A reference to an instance of cherry framework core class.
		 *
		 * @since 1.0.0
		 * @var   object
		 */
		private $core = null;

		/**
		 * Sets up needed actions/filters for the plugin to initialize.
		 *
		 * @since 1.0.0
		 */
		public function __construct() {
			// Set the constants needed by the plugin.
			$this->constants();

			// Load the installer core.
			add_action( 'after_setup_theme', require( trailingslashit( __DIR__ ) . 'cherry-framework/setup.php' ), 0 );

			// Load the core functions/classes required by the rest of the theme.
			add_action( 'after_setup_theme', array( $this, 'get_core' ), 1 );

			// Internationalize the text strings used.
			add_action( 'plugins_loaded', array( $this, 'lang' ), 2 );

			// Load the admin files.
			add_action( 'plugins_loaded', array( $this, 'admin_init' ), 3 );

			// Load public-facing style sheet.
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles' ) );

			// Load public-facing JavaScript.
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

			// Add custom body classes.
			add_filter( 'body_class', array( $this, 'body_classes' ) );

			// Render plugin into the footer area.
			add_action( 'wp_footer', array( $this, 'render' ) );
		}

		/**
		 * Defines constants for the plugin.
		 *
		 * @since 1.0.0
		 */
		public function constants() {

			/**
			 * Set the version number of the plugin.
			 *
			 * @since 1.0.0
			 */
			define( 'TM_HEADER_BANNER_VERSION', '1.0.0' );

			/**
			 * Set constant path to the plugin directory.
			 *
			 * @since 1.0.0
			 */
			define( 'TM_HEADER_BANNER_DIR', trailingslashit( plugin_dir_path( __FILE__ ) ) );

			/**
			 * Set constant path to the plugin URI.
			 *
			 * @since 1.0.0
			 */
			define( 'TM_HEADER_BANNER_URI', trailingslashit( plugin_dir_url( __FILE__ ) ) );

			/**
			 * Define plugin options key.
			 *
			 * @since 1.0.0
			 */
			define( 'TM_HEADER_BANNER_OPTIONS_NAME', 'tm_header_banner_options' );
		}

		/**
		 * Loads the core functions. These files are needed before loading anything else in the
		 * theme because they have required functions for use.
		 *
		 * @since  1.0.0
		 */
		public function get_core() {

			/**
			 * Fires before loads the core theme functions.
			 *
			 * @since 1.0.0
			 */
			do_action( 'tm_header_banner_core_before' );

			global $chery_core_version;

			if ( null !== $this->core ) {
				return $this->core;
			}

			if ( 0 < sizeof( $chery_core_version ) ) {
				$core_paths = array_values( $chery_core_version );
				require_once( $core_paths[0] );
			} else {
				die( 'Class Cherry_Core not found' );
			}

			$this->core = new Cherry_Core( array(
				'modules'  => array(
					'cherry-js-core' => array(
						'autoload' => true,
					),
					'cherry-ui-elements' => array(
						'autoload' => false,
					),
					'cherry-utility' => array(
						'autoload' => true,
					),
				),
			) );

			return $this->core;
		}

		/**
		 * Add custom body classes.
		 *
		 * @since 1.0.0
		 * @param array $classes Existing classes.
		 * @return array
		 */
		public function body_classes( $classes ) {

			$saved_options = get_option( TM_HEADER_BANNER_OPTIONS_NAME );
			$options = array_merge( tm_header_banner_admin()->get_defaults(), $saved_options );

			if ( isset( $options['enable'] ) &&
				 isset( $options['enable']['enable'] ) &&
				 'true' === $options['enable']['enable'] ) {
				$classes[] = 'tm-hb-enabled';
			}

			return $classes;
		}

		/**
		 * Render the plugin.
		 *
		 * @since  1.0.0
		 * @return bool Return false if `$_COOKIE['tm-header-banner-clicked']` was set.
		 */
		public function render() {
			$html = '';

			// Get the options & merge with defaults
			$options = get_option( TM_HEADER_BANNER_OPTIONS_NAME );
			$options = array_merge( tm_header_banner_admin()->get_defaults(), $options );
			$refresh = get_option( TM_HEADER_BANNER_OPTIONS_NAME . '_refresh' );

			update_option( TM_HEADER_BANNER_OPTIONS_NAME . '_refresh', false );

			// Check if plugin is enabled
			$enabled = 'true' === $options['enable']['enable'];

			// Check if animation is enabled
			$animate = 'true' === $options['animate']['animate'];

			// If user clicked the banner, we will have a cookie
			$clicked = array_key_exists( 'tm-header-banner-clicked', $_COOKIE ) && 'yes' === $_COOKIE['tm-header-banner-clicked'];

			// Check if title & description options are empty
			$is_empty = empty( $options['title'] ) && empty( $options['description'] );

			// Reactivation option
			$reactivation_on = isset( $options['reactivation_on'] ) &&
							   isset( $options['reactivation_on']['reactivation_on'] ) &&
							   'true' === $options['reactivation_on']['reactivation_on'];

			// If reactivation option enabled & the time slider is set to zero
			$reactivation_always = isset( $options['reactivation'] ) &&
								   '0' === $options['reactivation'];

			// If reactivation is disabled, don't reactivate always
			if ( ! $reactivation_on ) {
				$reactivation_always = false;
			}

			if ( $reactivation_always || $refresh ) {
				$clicked = false;
			}

			if ( $enabled && ! $is_empty ) {

				$data = array_merge( $options, array(
					'clicked' => $clicked,
					'reactivation_on' => $reactivation_on,
					'reactivation_always' => $reactivation_always,
					'animate' => $animate,
					'refresh' => $refresh,
				) );

				if ( $data['clicked'] && ! $data['refresh'] ) {
					return false;
				}

				$styles = array(
					'background-color' => $data['background_color'],
					'background-image' => $data['background_image'],
					'background-position' => $data['background_position'],
					'background-repeat' => $data['background_repeat'],
					'background-size' => $data['background_size'],
				);

				$main_template = locate_template( 'header-banner.php' );
				$styles_template = locate_template( 'header-banner-styles.php' );

				if ( ! $main_template ||
					 ! file_exists( $main_template ) ) {
					$main_template = TM_HEADER_BANNER_DIR . 'templates/header-banner.php';
				}

				if ( ! $styles_template ||
					 ! file_exists( $styles_template ) ) {
					$styles_template = TM_HEADER_BANNER_DIR . 'templates/header-banner-styles.php';
				}

				include $main_template;
				include $styles_template;
			}

			echo $html;

			return true;
		}

		/**
		 * Get hash of the title & description options
		 *
		 * @since  1.0.0
		 * @param  array $data Array that contains title & description.
		 * @return string      Hash value of the data
		 */
		public static function get_content_hash( $data ) {
			if ( ! isset( $data['title'] ) ||
				 ! isset( $data['description'] ) ) {
				return false;
			}

			return wp_hash( json_encode( $data ), 'nonce' );
		}

		/**
		 * Package attributes into a string
		 *
		 * @since  1.0.0
		 * @param  array $atts Attributes array.
		 * @return string
		 */
		public static function pack_atts( $atts ) {

			if ( ! is_array( $atts ) ||
				0 === sizeof( $atts ) ) {
				return $atts;
			}

			$attributes = '';

			foreach ( $atts as $key => $value ) {
				$attributes .= sprintf( ' %1$s="%2$s"',
					esc_attr( $key ),
					esc_attr( $value )
				);
			}

			return $attributes;
		}

		/**
		 * Loads admin files.
		 *
		 * @since 1.0.0
		 */
		public function admin_init() {
			require_once( TM_HEADER_BANNER_DIR . 'includes/admin/class.header-banner-admin.php' );
		}

		/**
		 * Loads the translation files.
		 *
		 * @since 1.0.0
		 */
		public function lang() {
			load_plugin_textdomain( 'tm-header-banner', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
		}

		/**
		 * Register and enqueue public-facing style sheet.
		 *
		 * @since 1.0.0
		 */
		public function enqueue_styles() {
			wp_enqueue_style( 'tm-header-banner-style', TM_HEADER_BANNER_URI . 'assets/css/styles.css', array(), TM_HEADER_BANNER_VERSION );
		}

		/**
		 * Register and enqueue public-facing style sheet.
		 *
		 * @since 1.0.0
		 */
		public function enqueue_scripts() {
			wp_enqueue_script( 'tm-header-banner-scripts', TM_HEADER_BANNER_URI . 'assets/js/scripts.js', array( 'jquery', 'cherry-js-core' ), TM_HEADER_BANNER_VERSION, true );
			wp_enqueue_script( 'tm-header-banner-cookie', TM_HEADER_BANNER_URI . 'assets/js/lib/cookie.js', array( 'jquery', 'cherry-js-core' ), TM_HEADER_BANNER_VERSION, true );
		}

		/**
		 * Returns the instance.
		 *
		 * @since  1.0.0
		 * @return object
		 */
		public static function get_instance() {

			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self;
			}

			return self::$instance;
		}
	}
}

if ( ! function_exists( 'tm_header_banner' ) ) {

	/**
	 * Returns instanse of the plugin class.
	 *
	 * @since  1.0.0
	 * @return object
	 */
	function tm_header_banner() {
		return Tm_Header_Banner::get_instance();
	}
}

tm_header_banner();
