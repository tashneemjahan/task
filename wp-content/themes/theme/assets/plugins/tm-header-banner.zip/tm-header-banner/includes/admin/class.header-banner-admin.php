<?php
/**
 * Sets up the admin functionality for the plugin.
 *
 * @package TM_Header_Banner
 * @subpackage Admin
 * @author  Template Monster
 * @license GPL-3.0+
 * @copyright  2002-2016, Template Monster
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die();
}

// If class `Tm_Header_Banner_Admin` doesn't exists yet.
if ( ! class_exists( 'Tm_Header_Banner_Admin' ) ) {

	/**
	 * Tm_Header_Banner_Admin class
	 *
	 * @since 1.0.0
	 */
	class Tm_Header_Banner_Admin {

		/**
		 * A reference to an instance of this class
		 *
		 * @since 1.0.0
		 * @var object
		 */
		private static $instance = null;

		/**
		 * Plugin option fields
		 *
		 * @since 1.0.0
		 * @var array
		 */
		public $fields = array();

		/**
		 * Class constructor
		 *
		 * @since 1.0.0
		 */
		public function __construct() {

			// Initialize plugin options.
			if ( ! get_option( TM_HEADER_BANNER_OPTIONS_NAME ) ) {
				$this->save_options( TM_HEADER_BANNER_OPTIONS_NAME, $this->get_defaults(), false );
			}

			if ( ! get_option( TM_HEADER_BANNER_OPTIONS_NAME . '_default' ) ) {
				$this->save_options( TM_HEADER_BANNER_OPTIONS_NAME . '_default', $this->get_defaults(), false );
			}

			// Load the admin menu.
			add_action( 'admin_menu', array( $this, 'menu' ) );

			// Load admin style sheet.
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_styles' ) );

			// Load admin JavaScript.
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

			// Init modules.
			add_action( 'after_setup_theme', array( $this, 'init' ) );

			add_action( 'wp_ajax_tm_header_banner_ajax_request', array( $this, 'handle_ajax_request' ) );
		}

		/**
		 * Get option fields.
		 *
		 * @since 1.0.0
		 * @return array
		 */
		public function get_fields() {
			return apply_filters( 'tm-header-banner-fields', array(
				'enable' => array(
					'type' => 'checkbox',
					'title' => esc_html__( 'Toggle the banner', 'tm-header-banner' ),
					'description' => esc_html__( 'Enable or disable the banner', 'tm-header-banner' ),
					'value' => array( 'on' ),
					'options' => array(
						'enable' => esc_html__( 'Show the banner', 'tm-header-banner' ),
					),
				),
				'reactivation_on' => array(
					'type' => 'checkbox',
					'title' => esc_html__( 'Toggle reactivation', 'tm-header-banner' ),
					'description' => esc_html__( 'Allow the Header Banner to be shown again.', 'tm-header-banner' ),
					'value' => array( 'on' ),
					'options' => array(
						'reactivation_on' => array(
							'label' => esc_html__( 'Reactivate', 'tm-header-banner' ),
							'slave' => 'reactivation_on',
						),
					),
				),
				'reactivation' => array(
					'type' => 'slider',
					'title' => esc_html__( 'Banner reactivation time', 'tm-header-banner' ),
					'description' => esc_html__( 'If user closed the banner, this option will allow you to control the period until the user will see the banner again. Option values are specified in days.', 'tm-header-banner' ),
					'max_value'  => 14,
					'min_value'  => 0,
					'value'      => 7,
					'step_value' => 1,
					'master' => 'reactivation_on',
				),
				'animate' => array(
					'type' => 'checkbox',
					'title' => esc_html__( 'Animate the Header Banner', 'tm-header-banner' ),
					'description' => esc_html__( 'Animate the appearing of the banner', 'tm-header-banner' ),
					'value' => array( 'on' ),
					'options' => array(
						'animate' => array(
							'label' => esc_html__( 'Animate', 'tm-header-banner' ),
							'slave' => 'animation_speed',
						),
					),
				),
				'animation_speed' => array(
					'type' => 'slider',
					'title' => esc_html__( 'Banner animation speed', 'tm-header-banner' ),
					'description' => esc_html__( 'Animation speed in milliseconds.', 'tm-header-banner' ),
					'max_value'  => 2000,
					'min_value'  => 100,
					'value'      => 200,
					'step_value' => 100,
					'master' => 'animation_speed',
				),
				'title' => array(
					'type' => 'text',
					'title' => esc_html__( 'Banner title', 'tm-header-banner' ),
					'description' => esc_html__( 'The title of the banner', 'tm-header-banner' ),
					'value' => esc_html__( 'Title', 'tm-header-banner' ),
				),
				'description' => array(
					'type' => 'textarea',
					'title' => esc_html__( 'Banner description', 'tm-header-banner' ),
					'description' => esc_html__( 'The description of the banner. This field also supports html code. You can use `<a href="#" class="tm-hb__button">Button</a>` for displaying a button.', 'tm-header-banner' ),
					'value' => esc_html__( 'Description', 'tm-header-banner' ),
				),
				'content_alignment' => array(
					'type' => 'select',
					'title' => esc_html__( 'Banner content alignment', 'tm-header-banner' ),
					'description' => esc_html__( 'The align of the banner content.', 'tm-header-banner' ),
					'value' => 'center',
					'options' => array(
						'left' => esc_html__( 'Left', 'tm-header-banner' ),
						'center' => esc_html__( 'Center', 'tm-header-banner' ),
						'right' => esc_html__( 'Right', 'tm-header-banner' ),
					),
				),
				'position_type' => array(
					'type' => 'select',
					'title' => esc_html__( 'Banner position type', 'tm-header-banner' ),
					'description' => esc_html__( 'The position of the banner.', 'tm-header-banner' ),
					'value' => 'floating',
					'options' => array(
						'floating' => esc_html__( 'Floating', 'tm-header-banner' ),
						'static' => esc_html__( 'Static', 'tm-header-banner' ),
					),
				),
				'background_color' => array(
					'type' => 'colorpicker',
					'title' => esc_html__( 'Banner background color', 'tm-header-banner' ),
					'description' => esc_html__( 'Banner background color.', 'tm-header-banner' ),
				),
				'background_image' => array(
					'type' => 'media',
					'title' => esc_html__( 'Banner background image', 'tm-header-banner' ),
					'description' => esc_html__( 'The background image of the banner.', 'tm-header-banner' ),
					'upload_button_text' => esc_html__( 'Choose Image', 'tm-header-banner' ),
					'multi_upload' => false,
				),
				'background_position' => array(
					'type' => 'select',
					'title' => esc_html__( 'Banner background position', 'tm-header-banner' ),
					'description' => esc_html__( 'Background image position.', 'tm-header-banner' ),
					'value' => 'center',
					'options' => array(
						'top-left' => esc_html__( 'Top Left', 'tm-header-banner' ),
						'top-center' => esc_html__( 'Top Center', 'tm-header-banner' ),
						'top-right'  => esc_html__( 'Top Right', 'tm-header-banner' ),
						'center-left' => esc_html__( 'Middle Left', 'tm-header-banner' ),
						'center' => esc_html__( 'Middle Center', 'tm-header-banner' ),
						'center-right' => esc_html__( 'Middle Right', 'tm-header-banner' ),
						'bottom-left' => esc_html__( 'Bottom Left', 'tm-header-banner' ),
						'bottom-center' => esc_html__( 'Bottom Center', 'tm-header-banner' ),
						'bottom-right' => esc_html__( 'Bottom Right', 'tm-header-banner' ),
					),
					'master' => 'background_image',
				),
				'background_repeat' => array(
					'type' => 'select',
					'title' => esc_html__( 'Repeat background', 'tm-header-banner' ),
					'description' => esc_html__( 'Repeat the background image.', 'tm-header-banner' ),
					'value'  => 'no-repeat',
					'options' => array(
						'repeat' => esc_html__( 'Repeat', 'tm-header-banner' ),
						'repeat-x' => esc_html__( 'Repeat X', 'tm-header-banner' ),
						'repeat-y' => esc_html__( 'Repeat Y', 'tm-header-banner' ),
						'no-repeat' => esc_html__( 'No repeat', 'tm-header-banner' ),
					),
					'master' => 'background_image',
				),
				'background_size' => array(
					'type' => 'select',
					'title' => esc_html__( 'Banner background size', 'tm-header-banner' ),
					'description' => esc_html__( 'Background image size.', 'tm-header-banner' ),
					'value' => 'inherit',
					'options' => array(
						'cover' => esc_html__( 'Cover', 'tm-header-banner' ),
						'contain' => esc_html__( 'Contain', 'tm-header-banner' ),
						'auto' => esc_html__( 'Auto', 'tm-header-banner' ),
					),
					'master' => 'background_image',
				),
			) );
		}

		/**
		 * Initialization of modules.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function init() {

			add_filter( 'cherry_core_js_ui_init_settings', array( $this, 'init_ui_js' ), 10 );

			$this->ui_builder = tm_header_banner()->get_core()->init_module( 'cherry-ui-elements', array(
				'ui-elements' => $this->get_field_types(),
			) );
		}

		/**
		 * Initialize UI elements JS
		 *
		 * @since  1.0.0
		 * @return array
		 */
		public function init_ui_js() {
			$settings = array(
				'auto_init' => true,
				'targets' => array( 'body' ),
			);

			return $settings;
		}

		/**
		 * Get fields default values.
		 *
		 * @since  1.0.0
		 * @return array
		 */
		public function get_defaults() {
			$defaults = array();

			foreach ( $this->get_fields() as $key => $config ) {
				$value = null;

				if ( array_key_exists( 'value', $config ) ) {
					$value = $config['value'];
				}

				$defaults[ $key ] = $value;
			}

			return $defaults;
		}

		/**
		 * Get field types.
		 *
		 * @since  1.0.0
		 * @return array
		 */
		public function get_field_types() {
			$field_types = array();

			foreach ( $this->get_fields() as $key => $config ) {

				if ( array_key_exists( 'type', $config ) ) {
					$field_types[] = $config['type'];
				}
			}

			return $field_types;
		}

		/**
		 * Get settings
		 *
		 * @since  1.0.0
		 * @param  array $current_options Current plugin options.
		 * @return array
		 */
		public function get_settings( $current_options ) {

			$settings = array(
				'ui-settings' => array(),
				'labels' => array(
					'save-button-text' => esc_html__( 'Save', 'tm-header-banner' ),
					'define-as-button-text' => esc_html__( 'Define as default', 'tm-header-banner' ),
					'restore-button-text' => esc_html__( 'Restore', 'tm-header-banner' ),
				),
			);

			foreach ( $this->get_fields() as $key => $field ) {
				$value = isset( $current_options[ $key ] ) ? $current_options[ $key ] : false;
				$value = ( false !== $value ) ? $value : Cherry_Toolkit::get_arg( $field, 'value', '' );
				$options = Cherry_Toolkit::get_arg( $field, 'options', array() );

				$args = array(
					'type' => Cherry_Toolkit::get_arg( $field, 'type', 'text' ),
					'id' => $key,
					'name' => $key,
					'value' => $value,
					'label' => Cherry_Toolkit::get_arg( $field, 'label', '' ),
					'options' => $options,
					'multiple'  => Cherry_Toolkit::get_arg( $field, 'multiple', false ),
					'filter' => Cherry_Toolkit::get_arg( $field, 'filter', false ),
					'size' => Cherry_Toolkit::get_arg( $field, 'size', 1 ),
					'null_option'  => Cherry_Toolkit::get_arg( $field, 'null_option', 'None' ),
					'multi_upload' => Cherry_Toolkit::get_arg( $field, 'multi_upload', true ),
					'library_type' => Cherry_Toolkit::get_arg( $field, 'library_type', 'image' ),
					'upload_button_text' => Cherry_Toolkit::get_arg( $field, 'upload_button_text', 'Choose' ),
					'max_value' => Cherry_Toolkit::get_arg( $field, 'max_value', '100' ),
					'min_value' => Cherry_Toolkit::get_arg( $field, 'min_value', '0' ),
					'max' => Cherry_Toolkit::get_arg( $field, 'max', '100' ),
					'min' => Cherry_Toolkit::get_arg( $field, 'min', '0' ),
					'step_value' => Cherry_Toolkit::get_arg( $field, 'step_value', '1' ),
					'style' => Cherry_Toolkit::get_arg( $field, 'style', 'normal' ),
					'display_input' => Cherry_Toolkit::get_arg( $field, 'display_input', true ),
					'controls'  => Cherry_Toolkit::get_arg( $field, 'controls', array() ),
					'toggle' => Cherry_Toolkit::get_arg( $field, 'toggle', array(
						'true_toggle'  => 'On',
						'false_toggle' => 'Off',
						'true_slave' => '',
						'false_slave'  => '',
					) ),
					'required'  => Cherry_Toolkit::get_arg( $field, 'required', false ),
					'master' => Cherry_Toolkit::get_arg( $field, 'master', '' ),
					'icon_data' => Cherry_Toolkit::get_arg( $field, 'icon_data', array() ),
				);

				$current_element = $this->ui_builder->get_ui_element_instance( $args['type'], $args );
				$settings['ui-settings'][] = array(
					'label' => Cherry_Toolkit::get_arg( $field, 'label', '' ),
					'title' => Cherry_Toolkit::get_arg( $field, 'title', '' ),
					'description' => Cherry_Toolkit::get_arg( $field, 'description', '' ),
					'ui-html' => $current_element->render(),
					'master' => Cherry_Toolkit::get_arg( $field, 'master', '' ),
				);
			}

			return $settings;
		}

		/**
		 * Save plugin options
		 *
		 * @since  1.0.0
		 * @param  string $option_name Option name.
		 * @param  array  $options Plugin options.
		 * @param  bool   $rehash Generate new hash.
		 * @return void
		 */
		public function save_options( $option_name, $options, $rehash ) {
			$refresh = false;

			if ( array_key_exists( 'description', $options ) ) {
				$options['description'] = stripslashes_deep( $options['description'] );
			}

			if ( $rehash ) {
				$old_hash = get_option( TM_HEADER_BANNER_OPTIONS_NAME . '_content_hash' );
				$new_hash = Tm_Header_Banner::get_content_hash( $options );

				if ( md5( $new_hash ) !== md5( $old_hash ) ) {
					$refresh = true;
				}
			}

			update_option( TM_HEADER_BANNER_OPTIONS_NAME . '_refresh', $refresh );
			update_option( $option_name, array_merge( $this->get_defaults(), $options ) );
		}

		/**
		 * Register the admin menu.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function menu() {
			add_menu_page(
				esc_html__( 'Header Banner', 'tm-header-banner' ),
				esc_html__( 'Header Banner', 'tm-header-banner' ),
				'edit_theme_options',
				'tm-header-banner-options',
				array( $this, 'render' ),
				TM_HEADER_BANNER_URI . 'assets/admin/images/menu-icon.png',
				63
			);
		}

		/**
		 * Register and enqueue admin style sheet.
		 *
		 * @since 1.0.0
		 * @param string $hook_suffix Hook suffix.
		 * @return void
		 */
		public function enqueue_styles( $hook_suffix ) {
			if ( 'toplevel_page_tm-header-banner-options' === $hook_suffix ) {
				wp_enqueue_style( 'tm-header-banner-admin-style', TM_HEADER_BANNER_URI . 'assets/admin/css/styles.css', array(), TM_HEADER_BANNER_VERSION );
			}
		}

		/**
		 * Register and enqueue admin style sheet.
		 *
		 * @since 1.0.0
		 * @param string $hook_suffix Hook suffix.
		 * @return void
		 */
		public function enqueue_scripts( $hook_suffix ) {
			if ( 'toplevel_page_tm-header-banner-options' == $hook_suffix ) {
				wp_enqueue_script( 'serialize-object', TM_HEADER_BANNER_URI . 'assets/admin/js/serialize-object.js', array( 'jquery' ), TM_HEADER_BANNER_VERSION, true );
				wp_enqueue_script( 'tm-header-banner-admin-scripts', TM_HEADER_BANNER_URI . 'assets/admin/js/scripts.js', array( 'jquery', 'cherry-js-core' ), TM_HEADER_BANNER_VERSION, true );

				$options_page_settings = array(
					'please_wait_processing'	=> esc_html__( 'Please wait, processing the previous request', 'tm-header-banner' ),
					'redirect_url'				=> menu_page_url( 'tm-header-banner-options', false ),
				);

				wp_localize_script( 'tm-header-banner-admin-scripts', 'tmHeaderBannerPluginSettings', $options_page_settings );
			}
		}

		/**
		 * Render options page.
		 *
		 * @since  1.0.0
		 * @return void
		 */
		public function render() {

			$saved_options = get_option( TM_HEADER_BANNER_OPTIONS_NAME );
			$current_options = array_merge( $this->get_defaults(), $saved_options );

			$data = array(
				'settings' => $this->get_settings( $current_options ),
			);

			include TM_HEADER_BANNER_DIR . '/templates/admin/options-page.php';
		}

		/**
		 * Save options via AJAX request.
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function handle_ajax_request() {

			if ( ! empty( $_POST ) &&
				 array_key_exists( 'post_array', $_POST ) &&
				 array_key_exists( 'nonce', $_POST ) &&
				 array_key_exists( 'type', $_POST ) &&
				 current_user_can( 'manage_options' ) ) {
				$post_array = $_POST['post_array'];
				$nonce = $_POST['nonce'];
				$type = $_POST['type'];
				$default_options = get_option( TM_HEADER_BANNER_OPTIONS_NAME . '_default' );

				if ( wp_verify_nonce( $nonce, 'cherry_ajax_nonce' ) ) {

					switch ( $type ) {

						case 'save' :
							tm_header_banner_admin()->save_options( TM_HEADER_BANNER_OPTIONS_NAME, $post_array, true );
							$response = array(
								'message' => esc_html__( 'Options have been saved', 'tm-header-banner' ),
								'type' => 'success-notice',
							);
						break;

						case 'define_as_default' :
							tm_header_banner_admin()->save_options( TM_HEADER_BANNER_OPTIONS_NAME . '_default', $post_array, false );
							$response = array(
								'message' => esc_html__( 'Settings have been defined as defaults', 'tm-header-banner' ),
								'type' => 'success-notice',
							);
						break;

						case 'restore' :
							tm_header_banner_admin()->save_options( TM_HEADER_BANNER_OPTIONS_NAME, $default_options, true );
							$response = array(
								'message' => esc_html__( 'Settings have been restored', 'tm-header-banner' ),
								'type' => 'success-notice',
							);
						break;
					}

					wp_send_json( $response );
				} else {
					wp_die();
				}
			} else {
				wp_die();
			}
		}

		/**
		 * Returns the instance.
		 *
		 * @since  1.0.0
		 * @return object
		 */
		public static function get_instance() {

			// If the single instance hasn't been set, set it now.
			if ( null == self::$instance ) {
				self::$instance = new self;
			}

			return self::$instance;
		}
	}

}

if ( ! function_exists( 'tm_header_banner_admin' ) ) {

	/**
	 * Returns instanse of the plugin class
	 *
	 * @since  1.0.0
	 * @return object
	 */
	function tm_header_banner_admin() {
		return Tm_Header_Banner_Admin::get_instance();
	}
}

tm_header_banner_admin();
