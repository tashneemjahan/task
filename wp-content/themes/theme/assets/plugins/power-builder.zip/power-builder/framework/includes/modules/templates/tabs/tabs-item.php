<?php
/**
 * Template part for displaying tab item content
 */
?>
<div class="<?php echo $this->_var( 'module_class' ); ?> tm_pb_tab clearfix"><?php
	echo $this->shortcode_content;
?></div> <!-- .tm_pb_tab -->